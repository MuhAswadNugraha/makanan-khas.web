<?php  
require_once '../lib/Database.php';
require_once '../lib/Helper.php';

$db = new Database;
$helper = new Helper;

// ambil input id untuk pencarian di database
// berdasarkan nip
$id = $_POST['id'];

// cari data pegawai berdasarkan nip (id)
$pegawai = $db->where('nip='.$id)->get('pegawai');

// ambil input file foto pegawai
// dan simpan ke variabel $upload_file
$upload_file = $_FILES['foto_pegawai'];

// jika input file tidak kosong
if(!empty($upload_file['name'])){

	// ambil ekstensi file (.jpg, .png, dll)
	// dari input file
	$ext = strtolower(pathinfo($upload_file['name'],PATHINFO_EXTENSION));

	// buat nama file baru menggunakan nama pegawai
	$nama_file = strtoupper(str_replace(' ','_',$_POST['nama_pegawai']).'_'.date('YmdHis').'.'.$ext);

	// jika upload file berhasil
	if($helper->upload_file($upload_file,$nama_file)){
		// hapus file lama
		unlink('../uploads/'.$pegawai['foto_pegawai']);
	}else{
		// jika upload file gagal
		// masukkan nilai 7 (gagal upload) ke variabel session pesan
		$_SESSION['pesan'] = 7;

		// arahkan tampilan ke tampil.php
		$helper->redirect_to('pegawai/tampil.php');
	}


}else{
	// jika input file kosong, 
	// isi variabel $nama_file dengan nama file yang lama
	$nama_file = $pegawai['foto_pegawai'];
}

// ambil input password
$password_baru = trim($_POST['password']);

// jika input password berisi nilai
if(!empty($password_baru)){

	// enkrip nilai password baru
	$password = password_hash($password_baru, PASSWORD_DEFAULT);
}else{
	//jika input password kosong
	// ambil password lama dari tabel pegawai
	$password = $pegawai['password'];
}

// sesuaikan urutan dan nama pada variabel array $data
// dengan urutan dan nama pada tabel pegawai
$data = [
	'nip'=>$_POST['nip'],  // jika field PK = AI (auto increment), jangan dimasukkan
	'id_departemen'=>$_POST['id_departemen'],
	'password'=>$password,
	'nama_pegawai'=>$_POST['nama_pegawai'],
	'jenis_kelamin'=>$_POST['jenis_kelamin'],
	'alamat'=>$_POST['alamat'],
	'telpon'=>$_POST['telpon'],
	'foto_pegawai'=>$nama_file
];

// simpan data ke tabel pegawai berdasarkan nip
// dan simpan respon ke variabel $result
$result = $db->where('nip='.$id)->update('pegawai',$data);

if($result > 0){  // jika simpan berhasil ($result > 0 ), 
	$pesan=1;  // maka berikan nilai variabel $pesan dengan 1, 
}else{
	$pesan=2;  // jika tidak berikan nilai 2
}


// masukkan nilai $pesan ke variabel session pesan
$_SESSION['pesan'] = $pesan;  

// arahkan tampilan ke tampil.php
$helper->redirect_to('pegawai/tampil.php');
?>
