<?php 
require_once '../header.php'; 
require_once '../lib/Database.php';

$db = new Database;

// ambil nilai id (nip) dari URL
$id = $_GET['id'];  

// ambil data dari tabel pegawai sesuai nip
$pegawai = $db->where('nip='.$id)->get('pegawai');
?>
<div class="container mt-5">
	<p class="fw-bold fs-5">Edit Data Pegawai</p>
	<div class="text-danger fw-bold small">* Kolom wajib diisi!</div>
	<div class="card p-3">
		<form action="update.php" method="POST" enctype="multipart/form-data">
			<div class="row">
				<div class="col-4">
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Nama Departemen</label>
						<select name="id_departemen" class="form-control" required oninvalid="this.setCustomValidity('Kolom belum dipilih')" oninput="this.setCustomValidity('')">
							<option value="">Belum dipilih</option>
							<?php 
							$query = $db->get('departemen'); 
							foreach($query as $qry){ 
								$selected = ($pegawai['id_departemen'] == $qry['id_departemen']) ? 'selected' : '';
								?>
								<option <?php echo $selected; ?> value="<?php echo $qry['id_departemen'] ?>"><?php echo $qry['nama_departemen'] ?></option>
								<?php 
							}?>
						</select>

						<!-- input dengan tipe tersembunyi (hidden) untuk menampung nip 
							untuk pencarian di update.php -->
						<input type="hidden" name="id" value="<?php echo $id ?>">
					</div>
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> NIP</label>
						<input type="text" name="nip" class="form-control" value="<?php echo $pegawai['nip'] ?>" autocomplete="off" placeholder="Ketikkan NIP Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>

					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Password</label>
						<input type="password" name="password" class="form-control" autocomplete="off" placeholder="Kosongkan jika tidak mengubah">
					</div>

					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span>Nama Pegawai</label>
						<input type="text" name="nama_pegawai" class="form-control" value="<?php echo $pegawai['nama_pegawai'] ?>" autocomplete="off" placeholder="Ketikkan Nama Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>
				</div>
				<div class="col-4">
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Jenis Kelamin</label>
						<select class="form-control" name="jenis_kelamin" required oninvalid="this.setCustomValidity('Kolom belum dipilih')" oninput="this.setCustomValidity('')">
							<?php  
							// mendefinisikan variabel array untuk data yang ditampilkan pada dropdown select
							$jenis_kelamin = [''=>'Belum Dipilih','1'=>'Laki-Laki','2'=>'Perempuan'];

							// melakukan looping untuk menghasilkan list options pada select
							foreach ($jenis_kelamin as $key => $value) { 

								// membuat nilai pada option select terpilih 
								// berdasarkan nilai jenis_kelamin dari tabel pegawai
								$selected = ($pegawai['jenis_kelamin'] == $key) ? 'selected' : '';?>
								<option <?php echo $selected ?> value="<?php echo $key; ?>"><?php echo $value ?></option>
								<?php 
							}?>
						</select>
					</div>
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Alamat Pegawai</label>
						<input type="text" name="alamat" class="form-control" value="<?php echo $pegawai['alamat'] ?>" autocomplete="off" placeholder="Ketikkan Alamat Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> No Telepon</label>
						<input type="text" name="telpon" class="form-control" value="<?php echo $pegawai['telpon'] ?>" autocomplete="off" placeholder="Ketikkan No Telepon Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>
				</div>
				<div class="col-4">
					<div class="mb-3">
						<label class="form-label">Foto Pegawai</label>
						<input type="file" name="foto_pegawai" class="form-control" accept="image/*" onchange="loadFile(event)">
						<div class="mt-3">Preview Foto</div>

						<?php  
						if(empty($pegawai['foto_pegawai'])){
							$src = '../assets/nopic.jpeg?'.rand(100,1000);
						}else{
							$src = '../uploads/'.$pegawai['foto_pegawai'].'?'.rand(100,1000);
						}
						?>
						<div><img id="foto" class="img-thumbnail" src="<?php echo $src ?>" style="height:150px; width: auto"></div>
						
						<script type="text/javascript">
							var loadFile = function(event) {
								var foto = document.getElementById('foto');
								foto.src = URL.createObjectURL(event.target.files[0]);
							};
						</script>
					</div>
					<hr>
					<button type="submit" class="btn btn-primary">Simpan</button>
					<?php echo $helper->link_to('Batal','pegawai/tampil.php',['class'=>'btn btn-danger']); ?>
				</div>
			</form>
		</div>
	</div>

