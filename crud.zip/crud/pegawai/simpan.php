<?php  
require_once '../lib/Database.php';
require_once '../lib/Helper.php';

$db = new Database;
$helper = new Helper;

// ambil input file foto pegawai
// dan simpan ke variabel $upload_file
$upload_file = $_FILES['foto_pegawai'];

// jika input file tidak kosong
if(!empty($upload_file['name'])){

	// ambil ekstensi file (.jpg, .png, dll)
	// dari input file
	$ext = strtolower(pathinfo($upload_file['name'],PATHINFO_EXTENSION));

	// buat nama file baru menggunakan nama pegawai
	$nama_file = strtoupper(str_replace(' ','_',$_POST['nama_pegawai']).'_'.date('YmdHis').'.'.$ext);

	// jika upload gagal
	if(!$helper->upload_file($upload_file,$nama_file)){
		// masukkan nilai 7 (gagal upload) ke variabel session pesan
		$_SESSION['pesan'] = 7;

		// arahkan tampilan ke tampil.php
		$helper->redirect_to('pegawai/tampil.php');
	}
}else{
	// jika input file kosong, 
	// kosongkan variabel $nama_file
	$nama_file = null;
}

// enkripsi input password sebelum disimpan
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// sesuaikan urutan dan nama pada variabel array $data
// dengan urutan dan nama pada tabel pegawai
$data = [
	'nip'=>$_POST['nip'],  // jika field PK = AI (auto increment), $_POST[''] diganti null
	'id_departemen'=>$_POST['id_departemen'],
	'password'=>$password,
	'nama_pegawai'=>$_POST['nama_pegawai'],
	'jenis_kelamin'=>$_POST['jenis_kelamin'],
	'alamat'=>$_POST['alamat'],
	'telpon'=>$_POST['telpon'],
	'foto_pegawai'=>$nama_file
];


// simpan data ke tabel pegawai
// dan simpan respon ke variabel $result
$result = $db->insert('pegawai',$data);

if($result > 0){  // jika simpan berhasil ($result > 0 ), 
	$pesan=1;  // maka berikan nilai variabel $pesan dengan 1, 
}else{
	$pesan=2;  // jika tidak berikan nilai 2
}


// masukkan nilai $pesan ke variabel session pesan
$_SESSION['pesan'] = $pesan;  

// arahkan tampilan ke tampil.php
$helper->redirect_to('pegawai/tampil.php');
?>