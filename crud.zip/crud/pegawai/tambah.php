<?php 
require_once '../header.php'; 
require_once '../lib/Database.php';

$db = new Database;
?>
<div class="container mt-5">
	<p class="fw-bold fs-5">Input Data Pegawai</p>
	<div class="text-danger fw-bold small">* Kolom wajib diisi!</div>
	<div class="card p-3">
		<form action="simpan.php" method="POST" enctype="multipart/form-data">
			<div class="row">
				<div class="col-4">
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Nama Departemen</label>
						<select name="id_departemen" class="form-control" required oninvalid="this.setCustomValidity('Kolom belum dipilih')" oninput="this.setCustomValidity('')">
							<option value="">Belum dipilih</option>
							<?php 
							$query = $db->get('departemen'); 
							foreach($query as $qry){ ?>
								<option value="<?php echo $qry['id_departemen'] ?>"><?php echo $qry['nama_departemen'] ?></option>
								<?php 
							}?>
						</select>
					</div>
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> NIP</label>
						<input type="text" name="nip" class="form-control" autocomplete="off" placeholder="Ketikkan NIP Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>

					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Password</label>
						<input type="password" name="password" class="form-control" autocomplete="off" placeholder="Ketikkan password" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>

					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span>Nama Pegawai</label>
						<input type="text" name="nama_pegawai" class="form-control" autocomplete="off" placeholder="Ketikkan Nama Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>
				</div>
				<div class="col-4">
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Jenis Kelamin</label>
						<select class="form-control" name="jenis_kelamin" required oninvalid="this.setCustomValidity('Kolom belum dipilih')" oninput="this.setCustomValidity('')">
							<option value="">Belum dipilih</option>
							<option value="1">Laki-Laki</option>
							<option value="2">Perempuan</option>
						</select>
					</div>
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> Alamat Pegawai</label>
						<input type="text" name="alamat" class="form-control" autocomplete="off" placeholder="Ketikkan Alamat Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>
					<div class="mb-3">
						<label class="form-label"><span class="text-danger">*</span> No Telepon</label>
						<input type="text" name="telpon" class="form-control" autocomplete="off" placeholder="Ketikkan No Telepon Pegawai" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					</div>
				</div>
				<div class="col-4">
					<div class="mb-3">
						<label class="form-label">Foto Pegawai</label>
						<input type="file" name="foto_pegawai" class="form-control" accept="image/*" onchange="loadFile(event)">
						<div class="mt-3">Preview Foto</div>
						<div><img id="foto" class="img-thumbnail" src="<?php echo '../assets/nopic.jpeg?'.rand(100,1000) ?>" style="height:150px; width: auto"></div>
						
						<script type="text/javascript">
							var loadFile = function(event) {
								var foto = document.getElementById('foto');
								foto.src = URL.createObjectURL(event.target.files[0]);
							};
						</script>
					</div>
					<hr>
					<button type="submit" class="btn btn-primary">Simpan</button>
					<?php echo $helper->link_to('Batal','pegawai/tampil.php',['class'=>'btn btn-danger']); ?>
				</div>
			</form>
		</div>
	</div>

