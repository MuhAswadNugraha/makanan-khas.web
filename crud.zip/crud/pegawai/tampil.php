<?php
require_once '../header.php';
require_once '../lib/Database.php';
?>

<!-- class container agar ada jarak kiri dan kanan -->
<div class="container">
	<!-- h3 utk ukuran huruf mt-5 utk jarak atas -->
	<div class="h3 mt-5">Data Pegawai</div>

	<!-- class btn btn-primary utk buat tombol warna biru -->
	<p><?php echo $helper->link_to('Tambah','pegawai/tambah.php',['class'=>'btn btn-primary']) ?></p>

	<?php 
	// menampilkan pesan setelah tambah, edit atau hapus
	echo $helper->show_message(); 
	?>

	<!-- membuat tabel data pegawai -->
	<table class="table table-bordered">  
		<!-- class table primary utk judul tabel warna biru -->
		<thead class="table-primary">
			<tr>
				<th class="text-center">No</th>
				<th>Nama Departemen</th>
				<th>NIP</th>
				<th>Nama Pegawai</th>
				<th>Jenis Kelamin</th>
				<th>Alamat</th>
				<th>No Telepon</th>
				<th class="text-center">Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php  
			$db = new Database;
			// mengambil data dari tabel pegawai join ke tabel departemen
			$query = $db->join('pegawai.id_departemen','departemen.id_departemen')->get('pegawai'); 
			$no=1; // inisialisasi nomor urut

			if(!empty($query)){  // jika hasil query tidak kosong
				//lakukan perulangan sebanyak jumlah baris di tabel
				foreach ($query as $qry) { 
					$jenis_kelamin = ['','Laki-Laki','Perempuan'];
					?>
					<tr>
						<td class="text-center"><?php echo $no++;?></td>
						<td><?php echo $qry['nama_departemen']; ?></td>
						<td><?php echo $qry['nip']; ?></td>
						<td><?php echo $qry['nama_pegawai']; ?></td>
						<td><?php echo $jenis_kelamin[$qry['jenis_kelamin']]; ?></td>
						<td><?php echo $qry['alamat']; ?></td>
						<td><?php echo $qry['telpon']; ?></td>
						<td class="text-center">
							<?php echo $helper->link_to('Edit','pegawai/edit.php?id='.$qry['nip'],['class'=>'btn btn-success']) ?>
							<?php echo $helper->link_to('Hapus','pegawai/hapus.php?id='.$qry['nip'],['class'=>'btn btn-danger']) ?>
						</td>
				<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<?php require_once '../footer.php' ?>