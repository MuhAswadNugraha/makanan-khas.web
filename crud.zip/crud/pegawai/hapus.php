<?php  
require_once '../lib/Database.php';
require_once '../lib/Helper.php';

$db = new Database;
$helper = new Helper;

// mengambil data id_departemen (id) dari URL
$id = $_GET['id'];

$pegawai = $db->where('nip='.$id)->get('pegawai');

// hapus file foto
unlink('../uploads/'.$pegawai['foto_pegawai']);

// menjalan query delete berdasarkan id_departemen
$result = $db->where('nip = '.$id)->delete('pegawai');

// jika hapus berhasil ($result > 0 ), maka $pesan = 3, jika tidak $pesan=4
$pesan = ($result > 0) ? 3 : 4;

session_start();
// masukkan nilai $pesan ke variabel session pesan
$_SESSION['pesan'] = $pesan;

$helper->redirect_to('pegawai/tampil.php');
?>