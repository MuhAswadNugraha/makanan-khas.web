-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 21 Bulan Mei 2024 pada 04.39
-- Versi server: 8.0.30
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_oop`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `departemen`
--

CREATE TABLE `departemen` (
  `id_departemen` int NOT NULL,
  `nama_departemen` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `departemen`
--

INSERT INTO `departemen` (`id_departemen`, `nama_departemen`) VALUES
(1, 'HRD'),
(2, 'IT'),
(3, 'Marketing'),
(4, 'Finance'),
(5, 'OP'),
(6, 'OB');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `nip` int NOT NULL,
  `id_departemen` int NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nama_pegawai` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `jenis_kelamin` tinyint(1) NOT NULL COMMENT '1=L 2=P',
  `alamat` varchar(100) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  `foto_pegawai` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`nip`, `id_departemen`, `password`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `telepon`, `foto_pegawai`) VALUES
(21, 1, '$2y$10$6rwKewgU4GnYqT9ml0G5PewOWEPxaxysrbwvfLkBB6in2DMF7stKG', 'aswad', 1, 'aswad', 'aswad', NULL),
(201, 4, '$2y$10$5pfBpJT7taGUKblpY5XkfOsUXvAI5ZBguICxTQoEk..pceIfN4dC6', '201', 1, '201', '210', NULL),
(206, 1, '$2y$10$VzBxkDAZ/n/UeJz3TbxhRuN/dBp9NNMyg9b2p/a57oe9l.XajF/nK', '207', 1, '206', '207', NULL),
(208, 5, '$2y$10$fSpCDo1TsCqyyHosckAb4OO8jWpfS8dvGHFdg1..eOX.QQ7tSd5cC', '2078', 1, '208', '208', NULL),
(209, 1, '$2y$10$R85OzPKKrM/Ic7lGvEZK2O3CipYV2N9Pp6q/0IFQyNTO1rrRogl1m', '209', 1, '209', '209', NULL),
(234, 2, '$2y$10$Yv3Po5mcDm6LJRWMtLdaZeWaPD7h8UPqcyFdH2zDK7BJu1mT.UjzW', '234', 1, '234', '234', NULL),
(21312, 6, '$2y$10$6.5lOA9RJ2Nxlx7ijkIFEuU1n/bLhG.gx.0X.DLIkfKYpQfAgFc6e', 'adawdas', 1, 'asdawfa', 'adawfawfs', NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `departemen`
--
ALTER TABLE `departemen`
  ADD PRIMARY KEY (`id_departemen`);

--
-- Indeks untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `pegawai_ibfk_1` (`id_departemen`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `departemen`
--
ALTER TABLE `departemen`
  MODIFY `id_departemen` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD CONSTRAINT `pegawai_ibfk_1` FOREIGN KEY (`id_departemen`) REFERENCES `departemen` (`id_departemen`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
