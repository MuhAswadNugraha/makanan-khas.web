<?php  
require_once 'lib/Helper.php';
$helper = new Helper;

session_destroy();  // menghapus semua variabel session
$helper->redirect_to();  // kembali ke halaman utama
?>