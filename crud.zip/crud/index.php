<?php 
require_once 'header.php'; // memanggil file header.php

if(!empty($_SESSION['nip'])){  // jika nilai variabel session 'nip' terisi, tampilkan dashboard UNMUL
?>
	<!-- logo dan teks UNMUL -->
	<div class="text-center" style="margin-top: 100px">  <!-- mt = margin top -->
		<img src="assets/logo_unmul.png" style="width: auto;height: 300px;">
		<div class="fw-bold fs-5 mt-5">Program Studi Pendidikan Komputer</div>
		<div class="fs-4">Fakultas Keguruan dan Ilmu Pendidikan</div>
		<div class="fs-3">Universitas Mulawarman Samarinda</div>
		<p class="small">&copy; 2024</p>
	</div>
<?php 
}else{ // jika nilai variabel session 'nip' kosong, tampilkan halaman login 
?>
	<div class="text-center mx-auto" style="margin-top: 100px; width: 350px;">
		<?php  
		echo $helper->show_message(); // menampilkan pesan respon
		?>
		<form action="signin.php" method="POST">

			<!-- logo unmul -->
			<img src="assets/logo_unmul.png" style="width: auto;height: 150px;">

			<h1 class="h3 mt-3 mb-3 fw-normal">Selamat Datang!</h1>

			<!-- input username -->
			<div class="form-floating mb-3">
				<input type="text" class="form-control" name="nip" id="floatingInput" placeholder="NIP" autocomplete="off">
				<label for="floatingInput">NIP</label>
			</div>

			<!-- input password -->
			<div class="form-floating mb-3">
				<input type="password" class="form-control" name="password" id="floatingPassword" placeholder="Password" autocomplete="off">
				<label for="floatingPassword">Password</label>
			</div>

			<!-- tombol submit -->
			<button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>

			<!-- copyright -->
			<p class="mt-5 mb-3 text-muted small">&copy; 2024<br>Prodi Pendidikan Komputer<br>FKIP - Universitas Mulawarman</p>
		</form>
	</div>
<?php 
}

// memanggil file footer
require_once 'footer.php'; ?>