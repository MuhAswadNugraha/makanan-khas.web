<?php 
require_once '../header.php';
require_once '../lib/Database.php';

$db = new Database;
?>

<!-- class container agar ada jarak kiri dan kanan -->
<div class="container">
	<!-- h3 utk ukuran huruf mt-5 utk jarak atas -->
	<div class="h3 mt-5">Data Departemen</div>

	<!-- class btn btn-primary utk buat tombol warna biru -->
	<p><?php echo $helper->link_to('Tambah','departemen/tambah.php',['class'=>'btn btn-primary']) ?></p>

	<?php 
	// menampilkan pesan
	echo $helper->show_message();?>

	<!-- membuat tabel data departemen -->
	<table class="table table-bordered">  
		<!-- class table primary utk judul tabel warna biru -->
		<thead class="table-primary">
			<tr>
				<th class="text-center">No</th>
				<th>Nama Departemen</th>
				<th class="text-center">Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php  
			$query = $db->get('departemen'); // mengambil semua data dari tabel departemen
			$no=1; // inisialisasi nomor urut

			if(!empty($query)){  // jika hasil query tidak kosong
				//lakukan perulangan sebanyak jumlah baris di tabel
				foreach ($query as $qry) { ?>
					<tr>
						<td class="text-center"><?php echo $no++;?></td> <!-- ++ adalah fungsi untuk menambahkan 1 ke nilai variabel $no -->
						<td><?php echo $qry['nama_departemen']; ?></td>
						<td class="text-center">
							<?php echo $helper->link_to('Edit','departemen/edit.php?id='.$qry['id_departemen'],['class'=>'btn btn-success']) ?>
							<?php echo $helper->link_to('Hapus','departemen/hapus.php?id='.$qry['id_departemen'],['class'=>'btn btn-danger']) ?>
						</td>
				<?php 
				}
			}
			?>
		</tbody>
	</table>
</div>
<?php require_once '../footer.php' ?>