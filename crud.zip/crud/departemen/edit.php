<?php 
require_once '../header.php'; 
require_once '../lib/Database.php';

$db = new Database;

// ambil nilai id dari URL
$id = $_GET['id'];

// ambil data dari tabel departemen sesuai id_departemen
$departemen = $db->where('id_departemen='.$id)->get('departemen');
?>
<div class="container mt-5">
	<div class="col-4">
		<p class="fw-bold fs-5">Edit Data Departemen</p>
		<div class="text-danger fw-bold small">* Kolom wajib diisi!</div>
		<div class="card p-3">
			<form action="update.php" method="POST">
				<div class="mb-3 has-validation">
					<label class="form-label"><span class="text-danger">*</span> Nama Departemen</label>
					<input type="text" name="nama_departemen" class="form-control" autocomplete="off" placeholder="Ketikkan Nama Departemen" value="<?php echo $departemen['nama_departemen'];?>" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
					<input type="hidden" name="id" value="<?php echo $departemen['id_departemen'];?>">
				</div>
				
				<button type="submit" class="btn btn-primary">Simpan</button>
				<?php echo $helper->link_to('Batal','departemen/tampil.php',['class'=>'btn btn-danger']); ?>
			</form>
		</div>
	</div>
</div>
