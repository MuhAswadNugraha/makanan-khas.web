<?php  
require_once '../lib/Database.php';
require_once '../lib/Helper.php';

$db = new Database;
$helper = new Helper;

// mengambil data id_departemen (id) dari URL
$id = $_GET['id'];

// menjalan query delete berdasarkan id_departemen
$result = $db->where('id_departemen = '.$id)->delete('departemen');

// jika hapus berhasil ($result > 0 ), maka $pesan = 3, jika tidak $pesan=4
$pesan = ($result > 0) ? 3 : 4;

// masukkan nilai $pesan ke variabel session pesan
$_SESSION['pesan'] = $pesan;

$helper->redirect_to('departemen/tampil.php');
?>