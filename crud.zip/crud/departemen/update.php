<?php  
require_once '../lib/Database.php';
require_once '../lib/Helper.php';

$db = new Database;
$helper = new Helper;

$id = $_POST['id'];

// sesuaikan urutan dan nama pada variabel array $data
// dengan urutan dan nama pada tabel departemen
$data = [
	'nama_departemen'=>$_POST['nama_departemen']
];

// simpan data ke tabel departemen
// dan simpan respon ke variabel $result
$result = $db->where('id_departemen='.$id)->update('departemen',$data);

if($result > 0){  // jika simpan berhasil ($result > 0 ), 
	$pesan=1;  // maka berikan nilai variabel $pesan dengan 1, 
}else{
	$pesan=2;  // jika tidak berikan nilai 2
}

$_SESSION['pesan'] = $pesan;   // masukkan nilai $pesan ke variabel session pesan

$helper->redirect_to('departemen/tampil.php');
?>
