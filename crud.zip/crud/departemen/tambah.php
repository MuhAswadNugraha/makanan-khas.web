<?php 
require_once '../header.php'; 
require_once '../lib/Database.php';

$db = new Database;
?>
<div class="container mt-5">
	<div class="col-4">
		<p class="fw-bold fs-5">Input Data Departemen</p>
		<div class="text-danger fw-bold small">* Kolom wajib diisi!</div>
		<div class="card p-3">
			<form action="simpan.php" method="POST">
				<div class="mb-3 has-validation">
					<label class="form-label"><span class="text-danger">*</span> Nama Departemen</label>
					<input type="text" name="nama_departemen" class="form-control" autocomplete="off" placeholder="Ketikkan Nama Departemen" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="this.setCustomValidity('')">
				</div>			
				<button type="submit" class="btn btn-primary">Simpan</button>
				<?php echo $helper->link_to('Batal','departemen/tampil.php',['class'=>'btn btn-danger']); ?>
			</form>
		</div>
	</div>
</div>