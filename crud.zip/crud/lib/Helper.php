<?php  
/*
* 01 Mei 2024
* Mata Kuliah Pemrograman Web
* Program Praktisi Mengajar Angkatan 4
* Semester Genap - 2023/2024
*
* Prodi Pendidikan Komputer - FKIP
* Universitas Mulawarman Samarinda
* 
* Project 	: CRUD OOP
* Nama File : Url.php
* Fungsi 	: library untuk mengatur link dan redirect page
*/

require_once 'Config.php';

class Helper extends Config{

	public function link_to($link_name, $uri, $attribute=[]){
		$attr = '';

		// jika nilai variabel $attribute tidak kosong
		if(!empty($attribute)){
			foreach ($attribute as $key => $value) {
				$attr .= $key.'="'.$value.'" '; // susun nilai atribut
			}
		}

		// buat link html <a href>..</a>
		$link = '<a href="'.$this->base_url.$uri.'"'.$attr.'>'.$link_name.'</a>';
		return $link;
	}

	// method utk mengarahkan halaman ke tampilan yang diinginkan
	// jika nilai variabel $uri kosong, maka otomatis akan diarahkan ke halaman depan
	public function redirect_to($uri=null){
		header("Location: ".$this->base_url.$uri);

		// stop proses
		exit();
	}

	// membuat pesan respon dari database (insert, update, delete)
	public function show_message(){
		$result = '';
		// membuat pesan berdasarkan kode 
		if(!empty($_SESSION['pesan'])){
			if($_SESSION['pesan'] == 1){
				$result = '<div class="alert alert-info">DATA BERHASIL DISIMPAN !</div>';
			}elseif($_SESSION['pesan'] == 2){
				$result = '<div class="alert alert-danger">DATA GAGAL DISIMPAN !</div>';
			}elseif($_SESSION['pesan'] == 3){
				$result = '<div class="alert alert-info">DATA BERHASIL DIHAPUS !</div>';
			}elseif($_SESSION['pesan'] == 4){
				$result = '<div class="alert alert-danger">DATA GAGAL DIHAPUS !</div>';
			}elseif($_SESSION['pesan'] == 5){
				$result = '<div class="alert alert-danger">NIP atau PASSWORD tidak boleh kosong!</div>';
			}elseif($_SESSION['pesan'] == 6){
				$result = '<div class="alert alert-danger">NIP atau PASSWORD tidak cocok!</div>';
			}elseif($_SESSION['pesan'] == 7){
				$result = '<div class="alert alert-danger">Upload file gagal, silahkan coba kembali!</div>';
			}
		}

		$_SESSION['pesan'] = '';  // mengosongkan variabel session 'pesan'
		return $result;
	}

	public function upload_file($upload_file,$nama_file){
		$file_baru = '../uploads/'.$nama_file;

		if (move_uploaded_file($upload_file["tmp_name"], $file_baru)) {
			return true;
		} else {
			return false;
		}
	}
}
?>