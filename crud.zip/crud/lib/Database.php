<?php  
/*
* 01 Mei 2024
* Mata Kuliah Pemrograman Web
* Program Praktisi Mengajar Angkatan 4
* Semester Genap - 2023/2024
*
* Prodi Pendidikan Komputer - FKIP
* Universitas Mulawarman Samarinda
*
* Project 	: CRUD OOP
* Nama File : Database.php
* Fungsi 	: library untuk menangani manipulasi database
*/

require_once 'Config.php';


class Database extends Config{

	// mendefinisikan variabel yang digunakan library Database
	protected $sql;
	protected $select;
	protected $join;
	protected $where;
	protected $error;


	// method connect() menghubungkan aplikasi dengan MySQL
	protected function connect(){
		try{
			// membuat koneksi ke database MySQL dengan konfigurasi pada Config.php
			$mysqli = new mysqli($this->hostname, $this->username, $this->password, $this->nama_database);
			return $mysqli;
		}catch (mysqli_sql_exception $e){ // mengembalikan status koneksi jika ada masalah
			echo "Gagal terkoneksi ke MySQL";  // jika koneksi gagal, tampilkan pesan
			exit();
		}
	}

	// method untuk menyusun perintah SELECT
	public function select($field){
		$this->select = 'SELECT '.$field;
		return $this;
	}

	// mengatur join tabel dari primary key ke foreign key
	public function join($from_table, $to_table){
		$from = explode('.',$from_table);  // mengubah string ke array
		$to = explode('.',$to_table);

		// $to[0] dan $from[0] adalah nama tabel
		// $to[1] dan $from[1] adalah nama field primary dan foreign key

		$this->join = ' JOIN '.$to[0].' ON '.$from[0].'.'.$from[1].' = '.$to[0].'.'.$to[1];
		return $this;
	}

	public function where($where){
		// menyusun statement WHERE
		$this->where .= (empty($this->where)) ? ' WHERE '.$where : ' AND '.$where;
		return $this;
	}

	// method untuk mengosongkan semua variabel yang
	// terlibat dalam query MySQL
	private function clear_query(){
		$this->sql='';
		$this->select='';
		$this->join='';
		$this->where='';
		$this->error='';
	}

	// method untuk mengambil data (SELECT)
	public function get($nama_tabel){
		$mysqli = $this->connect();  // membuat koneksi ke MySQL

		if(!empty($nama_tabel)){  // jika nilai variabel $nama_tabel tidak kosong
			$this->sql = "SELECT * FROM ".$nama_tabel.$this->join.$this->where;   // query untuk mengambil data dari tabel yang diminta

			try{
				// jalankan query 
				// contoh statement SQL : SELECT * from pegawai WHERE nip=1111
				$response = $mysqli->query($this->sql)->fetch_all(MYSQLI_ASSOC);

				if(count($response) > 1){  // jika hasil baris > 1
					$result = $response;
				}elseif(count($response) == 1){
					$result = $response[0];  // jika hasil baris cuma 1, maka ambil baris index pertama
				}else{
					$result=[];
				}

				$this->clear_query();  // mengosongkan variabel-variabel yang digunakan dalam query

			} catch (mysqli_sql_exception $e){  // jika terjadi error, masukkan ke variabel $e
				$result = 'SQL Error : '.$e;
			}
		}else{	
			// jika nilai variabel $nama_tabel kosong atau nama tabel tidak ada
			$result = $this->error.' Nama tabel tidak ditemukan';
		}

		$mysqli->close();  // mengakhiri koneksi MySQL

		return $result;		// kembalikan nilai $result kepada yang memanggil

	}


	// method untuk memasukkan data
	public function insert($nama_tabel, $arrayData){
		$mysqli = $this->connect();  // menghubungkan MySQL

		// deklarasi varianle bantu		
		$keys = '';		
		$values = '';

		// persiapkan statement query INSERT
		$this->sql = 'INSERT INTO '.$nama_tabel;

		// mempersiapkan array data menjadi SQL string
		foreach($arrayData as $key=>$value){

			// jika field pertama PK bernilai kosong / null
			// maka skip atau lanjutkan ke field berikut
			if($value === null){
				continue;
			}else{
				$keys .= "".$key.",";  // tambahkan , pada setiap akhir nama field
				$values .= "'".$value."',";  // tambahkan kutip antara nilai field
			}
		}
		
		$keys = substr($keys,0,-1);  // hapus tanda koma pada baris terakhir
		$values = substr($values,0,-1);

		// gabungkan semua string SQL menjadi lengkap
		// contoh statement SQL : INSERT INTO pegawai (field1,field2,...) VALUES(data1,data2,.....) nip=1111
		$this->sql .= ' ('.$keys.') VALUES ('.$values.');';

		// jalankan SQL query
		try{
			$mysqli->query($this->sql);
			$result = $mysqli->affected_rows;
			$this->clear_query();
		}catch(mysqli_sql_exception $e){
			$result = $this->error.$e;   // tampilkan pesan error jika SQL gagal
		}

		$mysqli->close();

		return $result;
	}


	// method untuk mengupdate data
	public function update($nama_tabel, $arrayData){
		$mysqli = $this->connect();  // menghubungkan MySQL
		$keys = '';		
		$values = '';
		$this->sql = 'UPDATE '.$nama_tabel.' SET ';

		// mempersiapkan array data menjadi SQL string
		foreach($arrayData as $key => $value){
			$values .= $key."='".$value."',";
		}

		$keys = substr($values,0,-1);  // hapus tanda koma pada baris terakhir

		// gabungkan semua string SQL
		// contoh statement SQL : UPDATE pegawai SET ..... WHERE nip=1111
		$this->sql .=  $keys.$this->where;
		
		// jalankan SQL query
		try{
			$mysqli->query($this->sql);
			$result = $mysqli->affected_rows;
			$this->clear_query();
		}catch(mysqli_sql_exception $e){
			$result = $this->error.$e;   // tampilkan pesan error jika SQL gagal
		}

		$mysqli->close();

		return $result;
	}

	// method untuk menghapus data
	public function delete($nama_tabel){
		$mysqli = $this->connect();

		// contoh statement SQL : DELETE from pegawai WHERE nip=1111
		$this->sql = 'DELETE FROM '.$nama_tabel.$this->where;

		try{
			$mysqli->query($this->sql);
			$result = $mysqli->affected_rows;
			$this->clear_query();
		}catch (mysqli_sql_exception $e){
			$result = $this->error.$e;
		}

		$mysqli->close();

		return $result;
	}
}


?>