<?php  
/*
* 01 Mei 2024
* Mata Kuliah Pemrograman Web
* Program Praktisi Mengajar Angkatan 4
* Semester Genap - 2023/2024
*
* Prodi Pendidikan Komputer - FKIP
* Universitas Mulawarman Samarinda
* 
* Project 	: CRUD OOP
* Nama File : Config.php
* Fungsi 	: library untuk menyimpan konfigurasi project
*/

class Config{
	// sesuaikan dengan URL project di browser
	public $base_url = 'http://localhost/crud/';

	//konfigurasi database
	protected $hostname = "localhost";
	protected $username = "root";
	protected $password = "";  //kosongkan jika tidak ada password
	protected $nama_database = "project_oop";

	// konfigurasi mode bekerja, development digunakan untuk debugging
	private $environment = 'development';  

	function __construct(){
		if($this->environment == 'development'){
			ini_set('display_errors', '1');
			ini_set('display_startup_errors', '1');
			error_reporting(E_ALL);
		}

		@session_start();  // memulai session
		date_default_timezone_set('Asia/Jakarta');  // set timezone untuk tanggal dan waktu
	}
}
?>