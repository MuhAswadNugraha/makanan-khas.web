<?php  
require_once 'lib/Database.php';
require_once 'lib/Helper.php';

$db = new Database;
$helper = new Helper;

// ambil nilai nip dan password dari form, 
// fungsi trim() untuk membersihkan nilai dari spasi kosong
$nip = trim($_POST['nip']);   
$password = trim($_POST['password']);

// jika nip atau password kosong
if(empty($nip) || empty($password)){
	// masukkan nilai 5 ke variabel session pesan
	$_SESSION['pesan'] = 5;

	// arahkan tampilan ke dashboard
	$helper->redirect_to();
}else{
	// mencari data pegawai berdasarkan nip yang diinputkan pengguna
	// hasil pencarian disimpan ke variabel $response
	$response = $db->where("nip='".$nip."'")->get('pegawai');

	// jika data ditemukan dan password valid
	if(!empty($response) && password_verify($password,$response['password'])){
		// masukkan nilai nip ke variabel session 'nip'
		$_SESSION['nip'] = $response['nip'];

		// masukkan nilai nama_pegawai ke variabel session 'nama_pegawai'
		$_SESSION['nama_pegawai'] = $response['nama_pegawai'];

		// masukkan nilai tanggal dan waktu ke variabel session 'waktu_login'
		$_SESSION['waktu_login'] = date('d-M-Y H:i');
	}else{	
		// jika data tidak ditemukan atau data ditemukan dan password tidak valid
		// masukkan nilai 6 ke variabel session 'pesan'
		$_SESSION['pesan'] = 6;
	}
}

// arahkan tampilan ke dashboard
$helper->redirect_to();
?>