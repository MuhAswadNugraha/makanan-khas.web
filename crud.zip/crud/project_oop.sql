-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Bulan Mei 2024 pada 06.39
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_oop`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `departemen`
--

CREATE TABLE `departemen` (
  `id_departemen` int(11) NOT NULL,
  `nama_departemen` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `departemen`
--

INSERT INTO `departemen` (`id_departemen`, `nama_departemen`) VALUES
(1, 'HRD'),
(2, 'TI'),
(3, 'FINANCE'),
(4, 'MARKETTING');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `nip` varchar(100) NOT NULL,
  `id_departemen` int(11) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `jenis_kelamin` tinyint(1) NOT NULL COMMENT '1=L 2=P',
  `alamat` varchar(100) NOT NULL,
  `telpon` varchar(20) NOT NULL,
  `foto_pegawai` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`nip`, `id_departemen`, `password`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `telpon`, `foto_pegawai`) VALUES
('12324', 4, '$2y$10$n.7ZdeZKpD3uyluv3hhI7OjeEEsB2CAlBPcDQxzmEmEx5je1oDoVu', '314324324', 1, '32435', '45345435', NULL),
('2102913', 2, '$2y$10$UqI2yQDcy3GqLc1zZmhFfe5EgN0U1VZetExWElZvO/qHgRP0BSmR6', 'Aldi', 1, 'Jalan Putar', '081234134', 'ALDI_20240522095426.GIF'),
('21212', 2, '$2y$10$atEHAcn2QRWeRlirgOdfv.QprWTpu.a57cfWqRxmarc1fEnYfYX5G', '432432', 2, 'asdawd', 'asdawfa', NULL),
('22061', 3, '$2y$10$CIq8NNo7k.sHQmQwzknTi.z7DQX/shv.IOcv2cp5HeKctEV7xBHie', 'aswad', 1, 'jalan buntu', '0812', NULL),
('awdasdasd', 3, '$2y$10$9fVh9z2kbYtCiK.WIH15FuY5xe0orLS3Yr2.pf/tiwAqdIuTrkoVS', 'faasfawf', 1, 'asfawfasf', 'awdfasfasf', NULL),
('awdawdas', 1, '$2y$10$9nDms5.HC8XFgavo9awaEupQF2W4Gxzope7j8zCWiRZtcxLi0R7BG', 'adawdasd', 2, 'dawf', 'sadwad', NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `departemen`
--
ALTER TABLE `departemen`
  ADD PRIMARY KEY (`id_departemen`);

--
-- Indeks untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `id_departemen` (`id_departemen`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `departemen`
--
ALTER TABLE `departemen`
  MODIFY `id_departemen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD CONSTRAINT `pegawai_ibfk_1` FOREIGN KEY (`id_departemen`) REFERENCES `departemen` (`id_departemen`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
