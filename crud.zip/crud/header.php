<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Project OOP</title>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" integrity="sha512-jnSuA4Ss2PkkikSOLtYs8BlYIeeIK1h99ty4YfvRPAlzr377vr3CXDb7sb7eEEBYjDtcYj+AjBH3FLv5uSJuXg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
	<?php
	require_once('lib/Helper.php'); // memanggil library Helper
	$helper = new Helper; // inisialisasi object baru
	?>
	<!-- navbar start -->
	<nav class="navbar navbar-expand-lg text-bg-primary">
		<div class="container-fluid">
			<a class="navbar-brand text-white" href="#">Project OOP</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<?php
			if (!empty($_SESSION['nip'])) {  // jika variabel session 'nip' terisi (sudah login)
			?>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">
							<?php
							// membuat link pada navbar, hasilnya adalah <a href="" class="nav-link text-white">Home</a>
							echo $helper->link_to('Home', '', ['class' => 'nav-link text-white']); ?>
						</li>
						<li class="nav-item">
							<?php echo $helper->link_to('Departemen', 'departemen/tampil.php', ['class' => 'nav-link text-white']); ?>
						</li>
						<li class="nav-item">
							<?php echo $helper->link_to('Pegawai', 'pegawai/tampil.php', ['class' => 'nav-link text-white']); ?>
						</li>
						<li class="nav-item">
							<?php echo $helper->link_to('Sign Out', 'signout.php', ['class' => 'nav-link text-white']); ?>
						</li>
					</ul>
					<span class="navbar-text text-white">
						<?php
						// cetak nama pegawai yang sudah login
						echo $_SESSION['nama_pegawai'] . ' [' . $_SESSION['waktu_login'] . ']';
						?>
					</span>
				</div>
			<?php
			} ?>
		</div>
	</nav>
	<!-- navbar end -->